// animal model
