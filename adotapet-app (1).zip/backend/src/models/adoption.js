// adoption model
